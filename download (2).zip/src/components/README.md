This is where generic, composable, re-usable UI components can be extracted from [../modules](../modules), e.g.:

- `<Button variant="..."/>`
- `<Checkbox />`
