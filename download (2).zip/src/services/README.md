Services operations can be called internally or via controllers located in:

[/src/pages/api/\[...entity\].ts](../pages/api/%5B...entity%5D.ts)
