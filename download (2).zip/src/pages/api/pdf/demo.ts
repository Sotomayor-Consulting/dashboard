import type { APIRoute } from "astro";
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const carbone = require("carbone");

// Detecta si 'soffice' existe (LibreOffice)
function hasSoffice(): Promise<boolean> {
  return new Promise((resolve) => {
    execFile("soffice", ["--version"], (err) => resolve(!err));
  });
}

// Intenta localizar la plantilla probando varias rutas típicas
async function findTemplate(): Promise<string | null> {
  const candidates = [
    path.join(process.cwd(), "templates", "test.docx"),        // <raíz>/templates/test.docx
    path.join(process.cwd(), "src", "templates", "test.docx"), // <raíz>/src/templates/test.docx
  ];
  for (const p of candidates) {
    try {
      const st = await fs.stat(p);
      if (st.isFile()) return p;
    } catch {}
  }
  return null;
}

export const GET: APIRoute = async ({ url }) => {
  const debug = url.searchParams.get("debug") === "1"; // ?debug=1 para ver errores

  try {
    const tplPath = await findTemplate();
    if (!tplPath) {
      const msg = [
        "[Export] NO SE ENCONTRÓ LA PLANTILLA.",
        `cwd: ${process.cwd()}`,
        "Rutas probadas:",
        `- ${path.join(process.cwd(), "templates", "test.docx")}`,
        `- ${path.join(process.cwd(), "src", "templates", "test.docx")}`,
      ].join("\n");
      if (debug) return new Response(msg, { status: 500 });
      return new Response("No se pudo generar el documento.", { status: 500 });
    }

    const tpl = await fs.readFile(tplPath);
    if (debug) {
      console.log("[Export] plantilla:", tplPath, "bytes:", tpl.byteLength);
    }

    const data = { nombre: "Sebastián" }; // <— datos dummy para probar

    // ¿Hay LibreOffice? (en tu entorno remoto será false)
    const canPdf = await hasSoffice();
    const primaryFmt = canPdf ? "pdf" : "docx";

    try {
      const out: Buffer = await new Promise((resolve, reject) => {
        carbone.render(tpl, data, { convertTo: primaryFmt }, (err: any, res: Buffer) => {
          if (err) return reject(err);
          resolve(res);
        });
      });

      return new Response(out, {
        status: 200,
        headers: {
          "Content-Type": canPdf
            ? "application/pdf"
            : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          "Content-Disposition": `attachment; filename="demo.${primaryFmt}"`,
          "Cache-Control": "no-store",
        },
      });
    } catch (e: any) {
      const msg = `[Export] Falla ${primaryFmt}: ${e?.message || e}`;
      if (debug) return new Response(msg, { status: 500 });
      // último intento: DOCX
      try {
        const outDocx: Buffer = await new Promise((resolve, reject) => {
          carbone.render(tpl, data, { convertTo: "docx" }, (err: any, res: Buffer) => {
            if (err) return reject(err);
            resolve(res);
          });
        });
        return new Response(outDocx, {
          status: 200,
          headers: {
            "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "Content-Disposition": "attachment; filename=\"demo.docx\"",
            "Cache-Control": "no-store",
          },
        });
      } catch (e2: any) {
        const msg2 = `[Export] También falló DOCX: ${e2?.message || e2}`;
        if (debug) return new Response(msg2, { status: 500 });
        return new Response("No se pudo generar el documento.", { status: 500 });
      }
    }
  } catch (e: any) {
    const msg = `[Export] Error inesperado: ${e?.message || e}`;
    if (debug) return new Response(msg, { status: 500 });
    return new Response("No se pudo generar el documento.", { status: 500 });
  }
};
